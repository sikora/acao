--
-- PostgreSQL database dump
--

-- Dumped from database version 9.1.4
-- Dumped by pg_dump version 9.1.3
-- Started on 2012-07-30 10:54:47 BRT

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 9 (class 2615 OID 32064)
-- Name: acao; Type: SCHEMA; Schema: -; Owner: acao
--

CREATE SCHEMA acao;


ALTER SCHEMA acao OWNER TO acao;

SET search_path = acao, pg_catalog;

SET default_tablespace = ts_acao;

SET default_with_oids = false;

--
-- TOC entry 171 (class 1259 OID 33048)
-- Dependencies: 9
-- Name: alertas; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE alertas (
    id_alerta integer NOT NULL,
    id_consolidacao integer NOT NULL,
    etapa integer NOT NULL,
    log_level character varying NOT NULL,
    datahora timestamp with time zone NOT NULL,
    id_documento_consolidado character varying,
    descricao_alerta character varying NOT NULL
);


ALTER TABLE acao.alertas OWNER TO acao;

--
-- TOC entry 172 (class 1259 OID 33054)
-- Dependencies: 171 9
-- Name: alertas_id_alerta_seq; Type: SEQUENCE; Schema: acao; Owner: acao
--

CREATE SEQUENCE alertas_id_alerta_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao.alertas_id_alerta_seq OWNER TO acao;

--
-- TOC entry 6228 (class 0 OID 0)
-- Dependencies: 172
-- Name: alertas_id_alerta_seq; Type: SEQUENCE OWNED BY; Schema: acao; Owner: acao
--

ALTER SEQUENCE alertas_id_alerta_seq OWNED BY alertas.id_alerta;


SET default_tablespace = '';

--
-- TOC entry 173 (class 1259 OID 33056)
-- Dependencies: 9
-- Name: bairros; Type: TABLE; Schema: acao; Owner: acao; Tablespace: 
--

CREATE TABLE bairros (
    id integer NOT NULL,
    nome character varying,
    regional character varying
);


ALTER TABLE acao.bairros OWNER TO acao;

--
-- TOC entry 174 (class 1259 OID 33062)
-- Dependencies: 9 173
-- Name: bairros_id_seq; Type: SEQUENCE; Schema: acao; Owner: acao
--

CREATE SEQUENCE bairros_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao.bairros_id_seq OWNER TO acao;

--
-- TOC entry 6230 (class 0 OID 0)
-- Dependencies: 174
-- Name: bairros_id_seq; Type: SEQUENCE OWNED BY; Schema: acao; Owner: acao
--

ALTER SEQUENCE bairros_id_seq OWNED BY bairros.id;


SET default_tablespace = ts_acao;

--
-- TOC entry 175 (class 1259 OID 33064)
-- Dependencies: 9
-- Name: consolidacao; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE consolidacao (
    id_consolidacao integer NOT NULL,
    id_definicao_consolidacao integer NOT NULL,
    data_ini timestamp with time zone,
    data_fim timestamp with time zone,
    dn character varying NOT NULL,
    status character varying NOT NULL
);


ALTER TABLE acao.consolidacao OWNER TO acao;

--
-- TOC entry 176 (class 1259 OID 33070)
-- Dependencies: 9 175
-- Name: consolidacao_id_consolidacao_seq; Type: SEQUENCE; Schema: acao; Owner: acao
--

CREATE SEQUENCE consolidacao_id_consolidacao_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao.consolidacao_id_consolidacao_seq OWNER TO acao;

--
-- TOC entry 6232 (class 0 OID 0)
-- Dependencies: 176
-- Name: consolidacao_id_consolidacao_seq; Type: SEQUENCE OWNED BY; Schema: acao; Owner: acao
--

ALTER SEQUENCE consolidacao_id_consolidacao_seq OWNED BY consolidacao.id_consolidacao;


--
-- TOC entry 177 (class 1259 OID 33072)
-- Dependencies: 9
-- Name: consolidador; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE consolidador (
    id_definicao_consolidacao integer NOT NULL,
    dn character varying NOT NULL
);


ALTER TABLE acao.consolidador OWNER TO acao;

--
-- TOC entry 178 (class 1259 OID 33078)
-- Dependencies: 9
-- Name: definicao_consolidacao; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE definicao_consolidacao (
    id_definicao_consolidacao integer NOT NULL,
    id_projeto integer,
    xml_schema character varying,
    nome character varying,
    status character varying,
    data_ini timestamp with time zone,
    data_fim timestamp with time zone
);


ALTER TABLE acao.definicao_consolidacao OWNER TO acao;

--
-- TOC entry 179 (class 1259 OID 33084)
-- Dependencies: 9 178
-- Name: definicao_consolidacao_id_definicao_consolidacao_seq; Type: SEQUENCE; Schema: acao; Owner: acao
--

CREATE SEQUENCE definicao_consolidacao_id_definicao_consolidacao_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao.definicao_consolidacao_id_definicao_consolidacao_seq OWNER TO acao;

--
-- TOC entry 6236 (class 0 OID 0)
-- Dependencies: 179
-- Name: definicao_consolidacao_id_definicao_consolidacao_seq; Type: SEQUENCE OWNED BY; Schema: acao; Owner: acao
--

ALTER SEQUENCE definicao_consolidacao_id_definicao_consolidacao_seq OWNED BY definicao_consolidacao.id_definicao_consolidacao;


--
-- TOC entry 180 (class 1259 OID 33086)
-- Dependencies: 9
-- Name: digitador; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE digitador (
    id_leitura integer NOT NULL,
    dn character varying NOT NULL
);


ALTER TABLE acao.digitador OWNER TO acao;

SET default_tablespace = '';

--
-- TOC entry 181 (class 1259 OID 33092)
-- Dependencies: 6087 6088 9
-- Name: dossie; Type: TABLE; Schema: acao; Owner: acao; Tablespace: 
--

CREATE TABLE dossie (
    id_volume character varying(255) NOT NULL,
    id_dossie character varying(255) NOT NULL,
    nome character varying(255),
    herda_permissoes integer DEFAULT 0 NOT NULL,
    invalidado integer DEFAULT 0 NOT NULL
);


ALTER TABLE acao.dossie OWNER TO acao;

SET default_tablespace = ts_acao;

--
-- TOC entry 182 (class 1259 OID 33100)
-- Dependencies: 9
-- Name: entrada_consolidacao; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE entrada_consolidacao (
    id_definicao_consolidacao integer NOT NULL,
    id_leitura integer NOT NULL,
    papel_leitura character varying
);


ALTER TABLE acao.entrada_consolidacao OWNER TO acao;

SET default_tablespace = '';

--
-- TOC entry 183 (class 1259 OID 33106)
-- Dependencies: 6089 6090 9
-- Name: entries; Type: TABLE; Schema: acao; Owner: acao; Tablespace: 
--

CREATE TABLE entries (
    entry_id integer NOT NULL,
    volume character varying(255),
    dossie character varying(255),
    documento character varying(255),
    resumo character varying(255),
    herda_permissoes integer DEFAULT 0 NOT NULL,
    invalidado integer DEFAULT 0 NOT NULL
);


ALTER TABLE acao.entries OWNER TO acao;

--
-- TOC entry 184 (class 1259 OID 33114)
-- Dependencies: 9 183
-- Name: entries_entry_id_seq; Type: SEQUENCE; Schema: acao; Owner: acao
--

CREATE SEQUENCE entries_entry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao.entries_entry_id_seq OWNER TO acao;

--
-- TOC entry 6240 (class 0 OID 0)
-- Dependencies: 184
-- Name: entries_entry_id_seq; Type: SEQUENCE OWNED BY; Schema: acao; Owner: acao
--

ALTER SEQUENCE entries_entry_id_seq OWNED BY entries.entry_id;


--
-- TOC entry 185 (class 1259 OID 33116)
-- Dependencies: 9
-- Name: escolas; Type: TABLE; Schema: acao; Owner: acao; Tablespace: 
--

CREATE TABLE escolas (
    id integer NOT NULL,
    nome character varying,
    endereco character varying,
    bairro character varying
);


ALTER TABLE acao.escolas OWNER TO acao;

--
-- TOC entry 186 (class 1259 OID 33122)
-- Dependencies: 9 185
-- Name: escolas_id_seq; Type: SEQUENCE; Schema: acao; Owner: acao
--

CREATE SEQUENCE escolas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao.escolas_id_seq OWNER TO acao;

--
-- TOC entry 6241 (class 0 OID 0)
-- Dependencies: 186
-- Name: escolas_id_seq; Type: SEQUENCE OWNED BY; Schema: acao; Owner: acao
--

ALTER SEQUENCE escolas_id_seq OWNED BY escolas.id;


SET default_tablespace = ts_acao;

--
-- TOC entry 187 (class 1259 OID 33124)
-- Dependencies: 9
-- Name: etapa_coleta_dados; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE etapa_coleta_dados (
    id_definicao_consolidacao integer NOT NULL,
    plugin_coleta_dados character varying NOT NULL,
    ordem_coleta_dados integer
);


ALTER TABLE acao.etapa_coleta_dados OWNER TO acao;

--
-- TOC entry 188 (class 1259 OID 33130)
-- Dependencies: 9
-- Name: etapa_transformacao; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE etapa_transformacao (
    id_definicao_consolidacao integer NOT NULL,
    plugin_transformacao character varying NOT NULL,
    ordem_transformacao integer
);


ALTER TABLE acao.etapa_transformacao OWNER TO acao;

--
-- TOC entry 189 (class 1259 OID 33136)
-- Dependencies: 9
-- Name: etapa_validacao; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE etapa_validacao (
    id_definicao_consolidacao integer NOT NULL,
    plugin_validacao character varying NOT NULL,
    ordem_validacao integer
);


ALTER TABLE acao.etapa_validacao OWNER TO acao;

SET default_tablespace = '';

--
-- TOC entry 190 (class 1259 OID 33142)
-- Dependencies: 9
-- Name: gin_index; Type: TABLE; Schema: acao; Owner: acao; Tablespace: 
--

CREATE TABLE gin_index (
    key character varying(50),
    value character varying(255),
    entry_id integer,
    label character varying(40)
);


ALTER TABLE acao.gin_index OWNER TO acao;

--
-- TOC entry 191 (class 1259 OID 33145)
-- Dependencies: 9
-- Name: hospitais; Type: TABLE; Schema: acao; Owner: acao; Tablespace: 
--

CREATE TABLE hospitais (
    id integer NOT NULL,
    nome character(255),
    rua character(255)
);


ALTER TABLE acao.hospitais OWNER TO acao;

--
-- TOC entry 192 (class 1259 OID 33151)
-- Dependencies: 9 191
-- Name: hospitais_id_seq; Type: SEQUENCE; Schema: acao; Owner: acao
--

CREATE SEQUENCE hospitais_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao.hospitais_id_seq OWNER TO acao;

--
-- TOC entry 6245 (class 0 OID 0)
-- Dependencies: 192
-- Name: hospitais_id_seq; Type: SEQUENCE OWNED BY; Schema: acao; Owner: acao
--

ALTER SEQUENCE hospitais_id_seq OWNED BY hospitais.id;


--
-- TOC entry 677 (class 1259 OID 929095)
-- Dependencies: 9
-- Name: indices; Type: TABLE; Schema: acao; Owner: acao; Tablespace: 
--

CREATE TABLE indices (
    id_indice integer NOT NULL,
    key_indice character varying NOT NULL
);


ALTER TABLE acao.indices OWNER TO acao;

--
-- TOC entry 676 (class 1259 OID 929093)
-- Dependencies: 9 677
-- Name: indices_id_indice_seq; Type: SEQUENCE; Schema: acao; Owner: acao
--

CREATE SEQUENCE indices_id_indice_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao.indices_id_indice_seq OWNER TO acao;

--
-- TOC entry 6246 (class 0 OID 0)
-- Dependencies: 676
-- Name: indices_id_indice_seq; Type: SEQUENCE OWNED BY; Schema: acao; Owner: acao
--

ALTER SEQUENCE indices_id_indice_seq OWNED BY indices.id_indice;


SET default_tablespace = ts_acao;

--
-- TOC entry 193 (class 1259 OID 33153)
-- Dependencies: 9
-- Name: instrumento; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE instrumento (
    id_projeto integer NOT NULL,
    nome character varying NOT NULL,
    xml_schema character varying NOT NULL,
    campo_controle character varying NOT NULL
);


ALTER TABLE acao.instrumento OWNER TO acao;

--
-- TOC entry 194 (class 1259 OID 33159)
-- Dependencies: 9
-- Name: leitura; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE leitura (
    id_leitura integer NOT NULL,
    id_projeto integer NOT NULL,
    nome character varying NOT NULL,
    coleta_ini timestamp with time zone,
    coleta_fim timestamp with time zone,
    digitacao_ini timestamp with time zone,
    digitacao_fim timestamp with time zone,
    revisao_ini timestamp with time zone,
    revisao_fim timestamp with time zone
);


ALTER TABLE acao.leitura OWNER TO acao;

--
-- TOC entry 195 (class 1259 OID 33165)
-- Dependencies: 9 194
-- Name: leitura_id_leitura_seq; Type: SEQUENCE; Schema: acao; Owner: acao
--

CREATE SEQUENCE leitura_id_leitura_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao.leitura_id_leitura_seq OWNER TO acao;

--
-- TOC entry 6249 (class 0 OID 0)
-- Dependencies: 195
-- Name: leitura_id_leitura_seq; Type: SEQUENCE OWNED BY; Schema: acao; Owner: acao
--

ALTER SEQUENCE leitura_id_leitura_seq OWNED BY leitura.id_leitura;


--
-- TOC entry 196 (class 1259 OID 33167)
-- Dependencies: 9
-- Name: logradouros; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE logradouros (
    cod double precision NOT NULL,
    nome text,
    codigo text,
    tipo text,
    titulo text,
    folha text,
    sentido text,
    lei text,
    data text,
    decreto text,
    data2 text,
    codlogini text,
    inicio1 text,
    codlogfim text,
    fim1 text,
    inicio2 text,
    fim2 text,
    utmhinicio text,
    utmvinicio text,
    utmhfim text,
    utmvfim text,
    bairro text,
    nomeanterior text,
    observacoes text
);


ALTER TABLE acao.logradouros OWNER TO acao;

--
-- TOC entry 197 (class 1259 OID 33173)
-- Dependencies: 9
-- Name: municipios; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE municipios (
    codmunic integer NOT NULL,
    nome character varying
);


ALTER TABLE acao.municipios OWNER TO acao;

--
-- TOC entry 198 (class 1259 OID 33179)
-- Dependencies: 197 9
-- Name: municipios_codmunic_seq; Type: SEQUENCE; Schema: acao; Owner: acao
--

CREATE SEQUENCE municipios_codmunic_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao.municipios_codmunic_seq OWNER TO acao;

--
-- TOC entry 6251 (class 0 OID 0)
-- Dependencies: 198
-- Name: municipios_codmunic_seq; Type: SEQUENCE OWNED BY; Schema: acao; Owner: acao
--

ALTER SEQUENCE municipios_codmunic_seq OWNED BY municipios.codmunic;


SET default_tablespace = '';

--
-- TOC entry 678 (class 1259 OID 929104)
-- Dependencies: 9
-- Name: nucleos; Type: TABLE; Schema: acao; Owner: acao; Tablespace: 
--

CREATE TABLE nucleos (
    nome character varying NOT NULL
);


ALTER TABLE acao.nucleos OWNER TO acao;

--
-- TOC entry 199 (class 1259 OID 33181)
-- Dependencies: 9
-- Name: permissao; Type: TABLE; Schema: acao; Owner: acao; Tablespace: 
--

CREATE TABLE permissao (
    entry_id integer NOT NULL,
    dn character varying(255)
);


ALTER TABLE acao.permissao OWNER TO acao;

--
-- TOC entry 200 (class 1259 OID 33184)
-- Dependencies: 9
-- Name: permissao_dossie; Type: TABLE; Schema: acao; Owner: acao; Tablespace: 
--

CREATE TABLE permissao_dossie (
    id_volume character varying(255) NOT NULL,
    id_dossie character varying(255) NOT NULL,
    dn character varying(255) NOT NULL
);


ALTER TABLE acao.permissao_dossie OWNER TO acao;

--
-- TOC entry 201 (class 1259 OID 33190)
-- Dependencies: 9 199
-- Name: permissao_entry_id_seq; Type: SEQUENCE; Schema: acao; Owner: acao
--

CREATE SEQUENCE permissao_entry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao.permissao_entry_id_seq OWNER TO acao;

--
-- TOC entry 6252 (class 0 OID 0)
-- Dependencies: 201
-- Name: permissao_entry_id_seq; Type: SEQUENCE OWNED BY; Schema: acao; Owner: acao
--

ALTER SEQUENCE permissao_entry_id_seq OWNED BY permissao.entry_id;


--
-- TOC entry 202 (class 1259 OID 33192)
-- Dependencies: 9
-- Name: permissao_volume; Type: TABLE; Schema: acao; Owner: acao; Tablespace: 
--

CREATE TABLE permissao_volume (
    id_volume character varying(255) NOT NULL,
    dn character varying(255) NOT NULL
);


ALTER TABLE acao.permissao_volume OWNER TO acao;

SET default_tablespace = ts_acao;

--
-- TOC entry 203 (class 1259 OID 33198)
-- Dependencies: 9
-- Name: projeto; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE projeto (
    id_projeto integer NOT NULL,
    nome text NOT NULL
);


ALTER TABLE acao.projeto OWNER TO acao;

--
-- TOC entry 204 (class 1259 OID 33204)
-- Dependencies: 203 9
-- Name: projeto_id_projeto_seq; Type: SEQUENCE; Schema: acao; Owner: acao
--

CREATE SEQUENCE projeto_id_projeto_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao.projeto_id_projeto_seq OWNER TO acao;

--
-- TOC entry 6254 (class 0 OID 0)
-- Dependencies: 204
-- Name: projeto_id_projeto_seq; Type: SEQUENCE OWNED BY; Schema: acao; Owner: acao
--

ALTER SEQUENCE projeto_id_projeto_seq OWNED BY projeto.id_projeto;


--
-- TOC entry 205 (class 1259 OID 33206)
-- Dependencies: 9
-- Name: regionais; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE regionais (
    id integer NOT NULL,
    nome character varying
);


ALTER TABLE acao.regionais OWNER TO acao;

--
-- TOC entry 206 (class 1259 OID 33212)
-- Dependencies: 205 9
-- Name: regionais_id_seq; Type: SEQUENCE; Schema: acao; Owner: acao
--

CREATE SEQUENCE regionais_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao.regionais_id_seq OWNER TO acao;

--
-- TOC entry 6256 (class 0 OID 0)
-- Dependencies: 206
-- Name: regionais_id_seq; Type: SEQUENCE OWNED BY; Schema: acao; Owner: acao
--

ALTER SEQUENCE regionais_id_seq OWNED BY regionais.id;


--
-- TOC entry 207 (class 1259 OID 33214)
-- Dependencies: 9
-- Name: revisor; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE revisor (
    id_leitura integer NOT NULL,
    dn character varying NOT NULL
);


ALTER TABLE acao.revisor OWNER TO acao;

SET default_tablespace = '';

--
-- TOC entry 208 (class 1259 OID 33220)
-- Dependencies: 9
-- Name: sessions; Type: TABLE; Schema: acao; Owner: acao; Tablespace: 
--

CREATE TABLE sessions (
    id character(72) NOT NULL,
    session_data text,
    expires integer
);


ALTER TABLE acao.sessions OWNER TO acao;

SET default_tablespace = ts_acao;

--
-- TOC entry 209 (class 1259 OID 33226)
-- Dependencies: 9
-- Name: unidades_saude; Type: TABLE; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE TABLE unidades_saude (
    id integer NOT NULL,
    nome character varying
);


ALTER TABLE acao.unidades_saude OWNER TO acao;

--
-- TOC entry 210 (class 1259 OID 33232)
-- Dependencies: 9 209
-- Name: unidades_saude_id_seq; Type: SEQUENCE; Schema: acao; Owner: acao
--

CREATE SEQUENCE unidades_saude_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao.unidades_saude_id_seq OWNER TO acao;

--
-- TOC entry 6258 (class 0 OID 0)
-- Dependencies: 210
-- Name: unidades_saude_id_seq; Type: SEQUENCE OWNED BY; Schema: acao; Owner: acao
--

ALTER SEQUENCE unidades_saude_id_seq OWNED BY unidades_saude.id;


SET default_tablespace = '';

--
-- TOC entry 211 (class 1259 OID 33234)
-- Dependencies: 6100 9
-- Name: volume; Type: TABLE; Schema: acao; Owner: acao; Tablespace: 
--

CREATE TABLE volume (
    id_volume character varying(255) NOT NULL,
    nome character varying(255),
    invalidado integer DEFAULT 0 NOT NULL
);


ALTER TABLE acao.volume OWNER TO acao;

--
-- TOC entry 6083 (class 2604 OID 34797)
-- Dependencies: 172 171
-- Name: id_alerta; Type: DEFAULT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY alertas ALTER COLUMN id_alerta SET DEFAULT nextval('alertas_id_alerta_seq'::regclass);


--
-- TOC entry 6084 (class 2604 OID 34798)
-- Dependencies: 174 173
-- Name: id; Type: DEFAULT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY bairros ALTER COLUMN id SET DEFAULT nextval('bairros_id_seq'::regclass);


--
-- TOC entry 6085 (class 2604 OID 34799)
-- Dependencies: 176 175
-- Name: id_consolidacao; Type: DEFAULT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY consolidacao ALTER COLUMN id_consolidacao SET DEFAULT nextval('consolidacao_id_consolidacao_seq'::regclass);


--
-- TOC entry 6086 (class 2604 OID 34800)
-- Dependencies: 179 178
-- Name: id_definicao_consolidacao; Type: DEFAULT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY definicao_consolidacao ALTER COLUMN id_definicao_consolidacao SET DEFAULT nextval('definicao_consolidacao_id_definicao_consolidacao_seq'::regclass);


--
-- TOC entry 6091 (class 2604 OID 34801)
-- Dependencies: 184 183
-- Name: entry_id; Type: DEFAULT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY entries ALTER COLUMN entry_id SET DEFAULT nextval('entries_entry_id_seq'::regclass);


--
-- TOC entry 6092 (class 2604 OID 34802)
-- Dependencies: 186 185
-- Name: id; Type: DEFAULT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY escolas ALTER COLUMN id SET DEFAULT nextval('escolas_id_seq'::regclass);


--
-- TOC entry 6093 (class 2604 OID 34803)
-- Dependencies: 192 191
-- Name: id; Type: DEFAULT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY hospitais ALTER COLUMN id SET DEFAULT nextval('hospitais_id_seq'::regclass);


--
-- TOC entry 6101 (class 2604 OID 929098)
-- Dependencies: 677 676 677
-- Name: id_indice; Type: DEFAULT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY indices ALTER COLUMN id_indice SET DEFAULT nextval('indices_id_indice_seq'::regclass);


--
-- TOC entry 6094 (class 2604 OID 34804)
-- Dependencies: 195 194
-- Name: id_leitura; Type: DEFAULT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY leitura ALTER COLUMN id_leitura SET DEFAULT nextval('leitura_id_leitura_seq'::regclass);


--
-- TOC entry 6095 (class 2604 OID 34805)
-- Dependencies: 198 197
-- Name: codmunic; Type: DEFAULT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY municipios ALTER COLUMN codmunic SET DEFAULT nextval('municipios_codmunic_seq'::regclass);


--
-- TOC entry 6096 (class 2604 OID 34806)
-- Dependencies: 201 199
-- Name: entry_id; Type: DEFAULT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY permissao ALTER COLUMN entry_id SET DEFAULT nextval('permissao_entry_id_seq'::regclass);


--
-- TOC entry 6097 (class 2604 OID 34807)
-- Dependencies: 204 203
-- Name: id_projeto; Type: DEFAULT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY projeto ALTER COLUMN id_projeto SET DEFAULT nextval('projeto_id_projeto_seq'::regclass);


--
-- TOC entry 6098 (class 2604 OID 34808)
-- Dependencies: 206 205
-- Name: id; Type: DEFAULT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY regionais ALTER COLUMN id SET DEFAULT nextval('regionais_id_seq'::regclass);


--
-- TOC entry 6099 (class 2604 OID 34809)
-- Dependencies: 210 209
-- Name: id; Type: DEFAULT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY unidades_saude ALTER COLUMN id SET DEFAULT nextval('unidades_saude_id_seq'::regclass);


SET default_tablespace = ts_acao;

--
-- TOC entry 6104 (class 2606 OID 34834)
-- Dependencies: 171 171
-- Name: alertas_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: ts_acao
--

ALTER TABLE ONLY alertas
    ADD CONSTRAINT alertas_pkey PRIMARY KEY (id_alerta);


--
-- TOC entry 6107 (class 2606 OID 34836)
-- Dependencies: 175 175
-- Name: consolidacao_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: ts_acao
--

ALTER TABLE ONLY consolidacao
    ADD CONSTRAINT consolidacao_pkey PRIMARY KEY (id_consolidacao);


--
-- TOC entry 6110 (class 2606 OID 34838)
-- Dependencies: 177 177 177
-- Name: consolidador_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: ts_acao
--

ALTER TABLE ONLY consolidador
    ADD CONSTRAINT consolidador_pkey PRIMARY KEY (id_definicao_consolidacao, dn);


--
-- TOC entry 6113 (class 2606 OID 34840)
-- Dependencies: 178 178
-- Name: definicao_consolidacao_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: ts_acao
--

ALTER TABLE ONLY definicao_consolidacao
    ADD CONSTRAINT definicao_consolidacao_pkey PRIMARY KEY (id_definicao_consolidacao);


--
-- TOC entry 6116 (class 2606 OID 34842)
-- Dependencies: 180 180 180
-- Name: digitador_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: ts_acao
--

ALTER TABLE ONLY digitador
    ADD CONSTRAINT digitador_pkey PRIMARY KEY (id_leitura, dn);


SET default_tablespace = '';

--
-- TOC entry 6119 (class 2606 OID 34844)
-- Dependencies: 181 181 181
-- Name: dossie_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: 
--

ALTER TABLE ONLY dossie
    ADD CONSTRAINT dossie_pkey PRIMARY KEY (id_volume, id_dossie);


SET default_tablespace = ts_acao;

--
-- TOC entry 6123 (class 2606 OID 34846)
-- Dependencies: 182 182 182
-- Name: entrada_consolidacao_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: ts_acao
--

ALTER TABLE ONLY entrada_consolidacao
    ADD CONSTRAINT entrada_consolidacao_pkey PRIMARY KEY (id_definicao_consolidacao, id_leitura);


SET default_tablespace = '';

--
-- TOC entry 6126 (class 2606 OID 34848)
-- Dependencies: 183 183
-- Name: entries_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: 
--

ALTER TABLE ONLY entries
    ADD CONSTRAINT entries_pkey PRIMARY KEY (entry_id);


SET default_tablespace = ts_acao;

--
-- TOC entry 6129 (class 2606 OID 34850)
-- Dependencies: 187 187 187
-- Name: etapa_coleta_dados_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: ts_acao
--

ALTER TABLE ONLY etapa_coleta_dados
    ADD CONSTRAINT etapa_coleta_dados_pkey PRIMARY KEY (id_definicao_consolidacao, plugin_coleta_dados);


--
-- TOC entry 6132 (class 2606 OID 34852)
-- Dependencies: 188 188 188
-- Name: etapa_transformacao_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: ts_acao
--

ALTER TABLE ONLY etapa_transformacao
    ADD CONSTRAINT etapa_transformacao_pkey PRIMARY KEY (id_definicao_consolidacao, plugin_transformacao);


--
-- TOC entry 6135 (class 2606 OID 34854)
-- Dependencies: 189 189 189
-- Name: etapa_validacao_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: ts_acao
--

ALTER TABLE ONLY etapa_validacao
    ADD CONSTRAINT etapa_validacao_pkey PRIMARY KEY (id_definicao_consolidacao, plugin_validacao);


SET default_tablespace = '';

--
-- TOC entry 6139 (class 2606 OID 34856)
-- Dependencies: 191 191
-- Name: id; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: 
--

ALTER TABLE ONLY hospitais
    ADD CONSTRAINT id PRIMARY KEY (id);


--
-- TOC entry 6168 (class 2606 OID 929103)
-- Dependencies: 677 677
-- Name: indices_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: 
--

ALTER TABLE ONLY indices
    ADD CONSTRAINT indices_pkey PRIMARY KEY (id_indice);


SET default_tablespace = ts_acao;

--
-- TOC entry 6142 (class 2606 OID 34858)
-- Dependencies: 193 193 193
-- Name: instrumento_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: ts_acao
--

ALTER TABLE ONLY instrumento
    ADD CONSTRAINT instrumento_pkey PRIMARY KEY (id_projeto, nome);


--
-- TOC entry 6145 (class 2606 OID 34860)
-- Dependencies: 194 194
-- Name: leitura_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: ts_acao
--

ALTER TABLE ONLY leitura
    ADD CONSTRAINT leitura_pkey PRIMARY KEY (id_leitura);


SET default_tablespace = '';

--
-- TOC entry 6150 (class 2606 OID 34862)
-- Dependencies: 197 197
-- Name: municipios_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: 
--

ALTER TABLE ONLY municipios
    ADD CONSTRAINT municipios_pkey PRIMARY KEY (codmunic);


--
-- TOC entry 6154 (class 2606 OID 34864)
-- Dependencies: 200 200 200 200
-- Name: permissao_dossie_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: 
--

ALTER TABLE ONLY permissao_dossie
    ADD CONSTRAINT permissao_dossie_pkey PRIMARY KEY (id_volume, id_dossie, dn);


--
-- TOC entry 6157 (class 2606 OID 34866)
-- Dependencies: 202 202 202
-- Name: permissao_volume_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: 
--

ALTER TABLE ONLY permissao_volume
    ADD CONSTRAINT permissao_volume_pkey PRIMARY KEY (id_volume, dn);


SET default_tablespace = ts_acao;

--
-- TOC entry 6148 (class 2606 OID 34868)
-- Dependencies: 196 196
-- Name: pk_logradouros; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: ts_acao
--

ALTER TABLE ONLY logradouros
    ADD CONSTRAINT pk_logradouros PRIMARY KEY (cod);


--
-- TOC entry 6159 (class 2606 OID 34870)
-- Dependencies: 203 203
-- Name: projeto_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: ts_acao
--

ALTER TABLE ONLY projeto
    ADD CONSTRAINT projeto_pkey PRIMARY KEY (id_projeto);


--
-- TOC entry 6162 (class 2606 OID 34872)
-- Dependencies: 207 207 207
-- Name: revisor_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: ts_acao
--

ALTER TABLE ONLY revisor
    ADD CONSTRAINT revisor_pkey PRIMARY KEY (id_leitura, dn);


SET default_tablespace = '';

--
-- TOC entry 6164 (class 2606 OID 34874)
-- Dependencies: 208 208
-- Name: sessions_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: 
--

ALTER TABLE ONLY sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 6166 (class 2606 OID 34876)
-- Dependencies: 211 211
-- Name: volume_pkey; Type: CONSTRAINT; Schema: acao; Owner: acao; Tablespace: 
--

ALTER TABLE ONLY volume
    ADD CONSTRAINT volume_pkey PRIMARY KEY (id_volume);


SET default_tablespace = ts_acao;

--
-- TOC entry 6102 (class 1259 OID 35223)
-- Dependencies: 171
-- Name: alertas_idx_id_consolidacao; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX alertas_idx_id_consolidacao ON alertas USING btree (id_consolidacao);


--
-- TOC entry 6105 (class 1259 OID 35224)
-- Dependencies: 175
-- Name: consolidacao_idx_id_definicao_consolidacao; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX consolidacao_idx_id_definicao_consolidacao ON consolidacao USING btree (id_definicao_consolidacao);


--
-- TOC entry 6108 (class 1259 OID 35225)
-- Dependencies: 177
-- Name: consolidador_idx_id_definicao_consolidacao; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX consolidador_idx_id_definicao_consolidacao ON consolidador USING btree (id_definicao_consolidacao);


--
-- TOC entry 6111 (class 1259 OID 35226)
-- Dependencies: 178
-- Name: definicao_consolidacao_idx_id_projeto; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX definicao_consolidacao_idx_id_projeto ON definicao_consolidacao USING btree (id_projeto);


--
-- TOC entry 6114 (class 1259 OID 35227)
-- Dependencies: 180
-- Name: digitador_idx_id_leitura; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX digitador_idx_id_leitura ON digitador USING btree (id_leitura);


SET default_tablespace = '';

--
-- TOC entry 6117 (class 1259 OID 35228)
-- Dependencies: 181
-- Name: dossie_idx_id_volume; Type: INDEX; Schema: acao; Owner: acao; Tablespace: 
--

CREATE INDEX dossie_idx_id_volume ON dossie USING btree (id_volume);


SET default_tablespace = ts_acao;

--
-- TOC entry 6120 (class 1259 OID 35229)
-- Dependencies: 182
-- Name: entrada_consolidacao_idx_id_definicao_consolidacao; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX entrada_consolidacao_idx_id_definicao_consolidacao ON entrada_consolidacao USING btree (id_definicao_consolidacao);


--
-- TOC entry 6121 (class 1259 OID 35230)
-- Dependencies: 182
-- Name: entrada_consolidacao_idx_id_leitura; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX entrada_consolidacao_idx_id_leitura ON entrada_consolidacao USING btree (id_leitura);


SET default_tablespace = '';

--
-- TOC entry 6124 (class 1259 OID 35231)
-- Dependencies: 183 183
-- Name: entries_idx_volume_dossie; Type: INDEX; Schema: acao; Owner: acao; Tablespace: 
--

CREATE INDEX entries_idx_volume_dossie ON entries USING btree (volume, dossie);


SET default_tablespace = ts_acao;

--
-- TOC entry 6127 (class 1259 OID 35232)
-- Dependencies: 187
-- Name: etapa_coleta_dados_idx_id_definicao_consolidacao; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX etapa_coleta_dados_idx_id_definicao_consolidacao ON etapa_coleta_dados USING btree (id_definicao_consolidacao);


--
-- TOC entry 6130 (class 1259 OID 35233)
-- Dependencies: 188
-- Name: etapa_transformacao_idx_id_definicao_consolidacao; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX etapa_transformacao_idx_id_definicao_consolidacao ON etapa_transformacao USING btree (id_definicao_consolidacao);


--
-- TOC entry 6133 (class 1259 OID 35234)
-- Dependencies: 189
-- Name: etapa_validacao_idx_id_definicao_consolidacao; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX etapa_validacao_idx_id_definicao_consolidacao ON etapa_validacao USING btree (id_definicao_consolidacao);


SET default_tablespace = '';

--
-- TOC entry 6136 (class 1259 OID 35235)
-- Dependencies: 190
-- Name: gin_index_idx_entry; Type: INDEX; Schema: acao; Owner: acao; Tablespace: 
--

CREATE INDEX gin_index_idx_entry ON gin_index USING btree (entry_id);


SET default_tablespace = ts_acao;

--
-- TOC entry 6140 (class 1259 OID 35236)
-- Dependencies: 193
-- Name: instrumento_idx_id_projeto; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX instrumento_idx_id_projeto ON instrumento USING btree (id_projeto);


--
-- TOC entry 6137 (class 1259 OID 35237)
-- Dependencies: 190 190
-- Name: ix_keyvalue; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX ix_keyvalue ON gin_index USING btree (value, key);


--
-- TOC entry 6146 (class 1259 OID 35238)
-- Dependencies: 196
-- Name: ix_nome; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX ix_nome ON logradouros USING btree (nome);


--
-- TOC entry 6143 (class 1259 OID 35239)
-- Dependencies: 194 194
-- Name: leitura_idx_id_projeto_nome; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX leitura_idx_id_projeto_nome ON leitura USING btree (id_projeto, nome);


SET default_tablespace = '';

--
-- TOC entry 6152 (class 1259 OID 35240)
-- Dependencies: 200 200
-- Name: permissao_dossie_idx_id_volume_id_dossie; Type: INDEX; Schema: acao; Owner: acao; Tablespace: 
--

CREATE INDEX permissao_dossie_idx_id_volume_id_dossie ON permissao_dossie USING btree (id_volume, id_dossie);


--
-- TOC entry 6151 (class 1259 OID 35241)
-- Dependencies: 199
-- Name: permissao_idx_entry_id; Type: INDEX; Schema: acao; Owner: acao; Tablespace: 
--

CREATE INDEX permissao_idx_entry_id ON permissao USING btree (entry_id);


--
-- TOC entry 6155 (class 1259 OID 35242)
-- Dependencies: 202
-- Name: permissao_volume_idx_id_volume; Type: INDEX; Schema: acao; Owner: acao; Tablespace: 
--

CREATE INDEX permissao_volume_idx_id_volume ON permissao_volume USING btree (id_volume);


SET default_tablespace = ts_acao;

--
-- TOC entry 6160 (class 1259 OID 35243)
-- Dependencies: 207
-- Name: revisor_idx_id_leitura; Type: INDEX; Schema: acao; Owner: acao; Tablespace: ts_acao
--

CREATE INDEX revisor_idx_id_leitura ON revisor USING btree (id_leitura);


--
-- TOC entry 6169 (class 2606 OID 929197)
-- Dependencies: 6106 171 175
-- Name: alertas_fk_id_consolidacao; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY alertas
    ADD CONSTRAINT alertas_fk_id_consolidacao FOREIGN KEY (id_consolidacao) REFERENCES consolidacao(id_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6171 (class 2606 OID 35612)
-- Dependencies: 175 6106 171
-- Name: alertas_id_consolidacao_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY alertas
    ADD CONSTRAINT alertas_id_consolidacao_fkey FOREIGN KEY (id_consolidacao) REFERENCES consolidacao(id_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6170 (class 2606 OID 35617)
-- Dependencies: 6106 171 175
-- Name: alertas_id_consolidacao_fkey1; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY alertas
    ADD CONSTRAINT alertas_id_consolidacao_fkey1 FOREIGN KEY (id_consolidacao) REFERENCES consolidacao(id_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6172 (class 2606 OID 929167)
-- Dependencies: 175 178 6112
-- Name: consolidacao_fk_id_definicao_consolidacao; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY consolidacao
    ADD CONSTRAINT consolidacao_fk_id_definicao_consolidacao FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6174 (class 2606 OID 35622)
-- Dependencies: 6112 178 175
-- Name: consolidacao_id_definicao_consolidacao_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY consolidacao
    ADD CONSTRAINT consolidacao_id_definicao_consolidacao_fkey FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6173 (class 2606 OID 35627)
-- Dependencies: 6112 175 178
-- Name: consolidacao_id_definicao_consolidacao_fkey1; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY consolidacao
    ADD CONSTRAINT consolidacao_id_definicao_consolidacao_fkey1 FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6175 (class 2606 OID 929172)
-- Dependencies: 178 6112 177
-- Name: consolidador_fk_id_definicao_consolidacao; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY consolidador
    ADD CONSTRAINT consolidador_fk_id_definicao_consolidacao FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6177 (class 2606 OID 35632)
-- Dependencies: 178 177 6112
-- Name: consolidador_id_definicao_consolidacao_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY consolidador
    ADD CONSTRAINT consolidador_id_definicao_consolidacao_fkey FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6176 (class 2606 OID 35637)
-- Dependencies: 178 6112 177
-- Name: consolidador_id_definicao_consolidacao_fkey1; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY consolidador
    ADD CONSTRAINT consolidador_id_definicao_consolidacao_fkey1 FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6178 (class 2606 OID 929157)
-- Dependencies: 203 178 6158
-- Name: definicao_consolidacao_fk_id_projeto; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY definicao_consolidacao
    ADD CONSTRAINT definicao_consolidacao_fk_id_projeto FOREIGN KEY (id_projeto) REFERENCES projeto(id_projeto) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6180 (class 2606 OID 35642)
-- Dependencies: 203 178 6158
-- Name: definicao_consolidacao_id_projeto_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY definicao_consolidacao
    ADD CONSTRAINT definicao_consolidacao_id_projeto_fkey FOREIGN KEY (id_projeto) REFERENCES projeto(id_projeto) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6179 (class 2606 OID 35647)
-- Dependencies: 178 6158 203
-- Name: definicao_consolidacao_id_projeto_fkey1; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY definicao_consolidacao
    ADD CONSTRAINT definicao_consolidacao_id_projeto_fkey1 FOREIGN KEY (id_projeto) REFERENCES projeto(id_projeto) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6181 (class 2606 OID 929202)
-- Dependencies: 6144 194 180
-- Name: digitador_fk_id_leitura; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY digitador
    ADD CONSTRAINT digitador_fk_id_leitura FOREIGN KEY (id_leitura) REFERENCES leitura(id_leitura) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6183 (class 2606 OID 35652)
-- Dependencies: 194 6144 180
-- Name: digitador_id_leitura_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY digitador
    ADD CONSTRAINT digitador_id_leitura_fkey FOREIGN KEY (id_leitura) REFERENCES leitura(id_leitura) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6182 (class 2606 OID 35657)
-- Dependencies: 6144 180 194
-- Name: digitador_id_leitura_fkey1; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY digitador
    ADD CONSTRAINT digitador_id_leitura_fkey1 FOREIGN KEY (id_leitura) REFERENCES leitura(id_leitura) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6184 (class 2606 OID 929122)
-- Dependencies: 6165 211 181
-- Name: dossie_fk_id_volume; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY dossie
    ADD CONSTRAINT dossie_fk_id_volume FOREIGN KEY (id_volume) REFERENCES volume(id_volume) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6185 (class 2606 OID 35662)
-- Dependencies: 211 6165 181
-- Name: dossie_id_volume_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY dossie
    ADD CONSTRAINT dossie_id_volume_fkey FOREIGN KEY (id_volume) REFERENCES volume(id_volume) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6187 (class 2606 OID 929212)
-- Dependencies: 182 6112 178
-- Name: entrada_consolidacao_fk_id_definicao_consolidacao; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY entrada_consolidacao
    ADD CONSTRAINT entrada_consolidacao_fk_id_definicao_consolidacao FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6186 (class 2606 OID 929217)
-- Dependencies: 182 6144 194
-- Name: entrada_consolidacao_fk_id_leitura; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY entrada_consolidacao
    ADD CONSTRAINT entrada_consolidacao_fk_id_leitura FOREIGN KEY (id_leitura) REFERENCES leitura(id_leitura) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6191 (class 2606 OID 35667)
-- Dependencies: 182 178 6112
-- Name: entrada_consolidacao_id_definicao_consolidacao_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY entrada_consolidacao
    ADD CONSTRAINT entrada_consolidacao_id_definicao_consolidacao_fkey FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6190 (class 2606 OID 35672)
-- Dependencies: 6112 182 178
-- Name: entrada_consolidacao_id_definicao_consolidacao_fkey1; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY entrada_consolidacao
    ADD CONSTRAINT entrada_consolidacao_id_definicao_consolidacao_fkey1 FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6189 (class 2606 OID 35677)
-- Dependencies: 182 6144 194
-- Name: entrada_consolidacao_id_leitura_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY entrada_consolidacao
    ADD CONSTRAINT entrada_consolidacao_id_leitura_fkey FOREIGN KEY (id_leitura) REFERENCES leitura(id_leitura) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6188 (class 2606 OID 35682)
-- Dependencies: 6144 182 194
-- Name: entrada_consolidacao_id_leitura_fkey1; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY entrada_consolidacao
    ADD CONSTRAINT entrada_consolidacao_id_leitura_fkey1 FOREIGN KEY (id_leitura) REFERENCES leitura(id_leitura) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6192 (class 2606 OID 929132)
-- Dependencies: 183 211 6165
-- Name: entries_fk_volume; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY entries
    ADD CONSTRAINT entries_fk_volume FOREIGN KEY (volume) REFERENCES volume(id_volume) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6193 (class 2606 OID 929127)
-- Dependencies: 181 183 6118 183 181
-- Name: entries_fk_volume_dossie; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY entries
    ADD CONSTRAINT entries_fk_volume_dossie FOREIGN KEY (volume, dossie) REFERENCES dossie(id_volume, id_dossie) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6195 (class 2606 OID 35687)
-- Dependencies: 181 6118 183 181 183
-- Name: entries_volume_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY entries
    ADD CONSTRAINT entries_volume_fkey FOREIGN KEY (volume, dossie) REFERENCES dossie(id_volume, id_dossie) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6194 (class 2606 OID 35692)
-- Dependencies: 183 6165 211
-- Name: entries_volume_fkey1; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY entries
    ADD CONSTRAINT entries_volume_fkey1 FOREIGN KEY (volume) REFERENCES volume(id_volume) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6196 (class 2606 OID 929177)
-- Dependencies: 178 187 6112
-- Name: etapa_coleta_dados_fk_id_definicao_consolidacao; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY etapa_coleta_dados
    ADD CONSTRAINT etapa_coleta_dados_fk_id_definicao_consolidacao FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6198 (class 2606 OID 35697)
-- Dependencies: 6112 187 178
-- Name: etapa_coleta_dados_id_definicao_consolidacao_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY etapa_coleta_dados
    ADD CONSTRAINT etapa_coleta_dados_id_definicao_consolidacao_fkey FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6197 (class 2606 OID 35702)
-- Dependencies: 187 6112 178
-- Name: etapa_coleta_dados_id_definicao_consolidacao_fkey1; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY etapa_coleta_dados
    ADD CONSTRAINT etapa_coleta_dados_id_definicao_consolidacao_fkey1 FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6199 (class 2606 OID 929182)
-- Dependencies: 6112 188 178
-- Name: etapa_transformacao_fk_id_definicao_consolidacao; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY etapa_transformacao
    ADD CONSTRAINT etapa_transformacao_fk_id_definicao_consolidacao FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6201 (class 2606 OID 35707)
-- Dependencies: 6112 188 178
-- Name: etapa_transformacao_id_definicao_consolidacao_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY etapa_transformacao
    ADD CONSTRAINT etapa_transformacao_id_definicao_consolidacao_fkey FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6200 (class 2606 OID 35712)
-- Dependencies: 178 6112 188
-- Name: etapa_transformacao_id_definicao_consolidacao_fkey1; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY etapa_transformacao
    ADD CONSTRAINT etapa_transformacao_id_definicao_consolidacao_fkey1 FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6202 (class 2606 OID 929187)
-- Dependencies: 178 189 6112
-- Name: etapa_validacao_fk_id_definicao_consolidacao; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY etapa_validacao
    ADD CONSTRAINT etapa_validacao_fk_id_definicao_consolidacao FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6204 (class 2606 OID 35717)
-- Dependencies: 189 6112 178
-- Name: etapa_validacao_id_definicao_consolidacao_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY etapa_validacao
    ADD CONSTRAINT etapa_validacao_id_definicao_consolidacao_fkey FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6203 (class 2606 OID 35722)
-- Dependencies: 6112 178 189
-- Name: etapa_validacao_id_definicao_consolidacao_fkey1; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY etapa_validacao
    ADD CONSTRAINT etapa_validacao_id_definicao_consolidacao_fkey1 FOREIGN KEY (id_definicao_consolidacao) REFERENCES definicao_consolidacao(id_definicao_consolidacao) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6206 (class 2606 OID 35727)
-- Dependencies: 183 190 6125
-- Name: gin_index_entry_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY gin_index
    ADD CONSTRAINT gin_index_entry_fkey FOREIGN KEY (entry_id) REFERENCES entries(entry_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6205 (class 2606 OID 929137)
-- Dependencies: 190 6125 183
-- Name: gin_index_fk_entry_id; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY gin_index
    ADD CONSTRAINT gin_index_fk_entry_id FOREIGN KEY (entry_id) REFERENCES entries(entry_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6207 (class 2606 OID 929162)
-- Dependencies: 203 193 6158
-- Name: instrumento_fk_id_projeto; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY instrumento
    ADD CONSTRAINT instrumento_fk_id_projeto FOREIGN KEY (id_projeto) REFERENCES projeto(id_projeto) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6209 (class 2606 OID 35732)
-- Dependencies: 203 193 6158
-- Name: instrumento_id_projeto_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY instrumento
    ADD CONSTRAINT instrumento_id_projeto_fkey FOREIGN KEY (id_projeto) REFERENCES projeto(id_projeto) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6208 (class 2606 OID 35737)
-- Dependencies: 6158 193 203
-- Name: instrumento_id_projeto_fkey1; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY instrumento
    ADD CONSTRAINT instrumento_id_projeto_fkey1 FOREIGN KEY (id_projeto) REFERENCES projeto(id_projeto) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6210 (class 2606 OID 929192)
-- Dependencies: 193 194 6141 194 193
-- Name: leitura_fk_id_projeto_nome; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY leitura
    ADD CONSTRAINT leitura_fk_id_projeto_nome FOREIGN KEY (id_projeto, nome) REFERENCES instrumento(id_projeto, nome) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6212 (class 2606 OID 35742)
-- Dependencies: 6141 194 193 194 193
-- Name: leitura_id_projeto_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY leitura
    ADD CONSTRAINT leitura_id_projeto_fkey FOREIGN KEY (id_projeto, nome) REFERENCES instrumento(id_projeto, nome) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6211 (class 2606 OID 35747)
-- Dependencies: 194 194 193 193 6141
-- Name: leitura_id_projeto_fkey1; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY leitura
    ADD CONSTRAINT leitura_id_projeto_fkey1 FOREIGN KEY (id_projeto, nome) REFERENCES instrumento(id_projeto, nome) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6215 (class 2606 OID 929147)
-- Dependencies: 6118 181 181 200 200
-- Name: permissao_dossie_fk_id_volume_id_dossie; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY permissao_dossie
    ADD CONSTRAINT permissao_dossie_fk_id_volume_id_dossie FOREIGN KEY (id_volume, id_dossie) REFERENCES dossie(id_volume, id_dossie) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6216 (class 2606 OID 35752)
-- Dependencies: 200 200 181 181 6118
-- Name: permissao_dossie_id_volume_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY permissao_dossie
    ADD CONSTRAINT permissao_dossie_id_volume_fkey FOREIGN KEY (id_volume, id_dossie) REFERENCES dossie(id_volume, id_dossie) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6214 (class 2606 OID 35757)
-- Dependencies: 199 183 6125
-- Name: permissao_entry_id_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY permissao
    ADD CONSTRAINT permissao_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES entries(entry_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6213 (class 2606 OID 929142)
-- Dependencies: 199 6125 183
-- Name: permissao_fk_entry_id; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY permissao
    ADD CONSTRAINT permissao_fk_entry_id FOREIGN KEY (entry_id) REFERENCES entries(entry_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6217 (class 2606 OID 929152)
-- Dependencies: 202 6165 211
-- Name: permissao_volume_fk_id_volume; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY permissao_volume
    ADD CONSTRAINT permissao_volume_fk_id_volume FOREIGN KEY (id_volume) REFERENCES volume(id_volume) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6218 (class 2606 OID 35762)
-- Dependencies: 202 211 6165
-- Name: permissao_volume_id_volume_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY permissao_volume
    ADD CONSTRAINT permissao_volume_id_volume_fkey FOREIGN KEY (id_volume) REFERENCES volume(id_volume) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6219 (class 2606 OID 929207)
-- Dependencies: 194 207 6144
-- Name: revisor_fk_id_leitura; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY revisor
    ADD CONSTRAINT revisor_fk_id_leitura FOREIGN KEY (id_leitura) REFERENCES leitura(id_leitura) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6223 (class 2606 OID 35767)
-- Dependencies: 207 6144 194
-- Name: revisor_id_leitura_fkey; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY revisor
    ADD CONSTRAINT revisor_id_leitura_fkey FOREIGN KEY (id_leitura) REFERENCES leitura(id_leitura) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6222 (class 2606 OID 35772)
-- Dependencies: 6144 207 194
-- Name: revisor_id_leitura_fkey1; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY revisor
    ADD CONSTRAINT revisor_id_leitura_fkey1 FOREIGN KEY (id_leitura) REFERENCES leitura(id_leitura) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6221 (class 2606 OID 35777)
-- Dependencies: 194 6144 207
-- Name: revisor_id_leitura_fkey2; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY revisor
    ADD CONSTRAINT revisor_id_leitura_fkey2 FOREIGN KEY (id_leitura) REFERENCES leitura(id_leitura) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6220 (class 2606 OID 35782)
-- Dependencies: 194 6144 207
-- Name: revisor_id_leitura_fkey3; Type: FK CONSTRAINT; Schema: acao; Owner: acao
--

ALTER TABLE ONLY revisor
    ADD CONSTRAINT revisor_id_leitura_fkey3 FOREIGN KEY (id_leitura) REFERENCES leitura(id_leitura) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE;


--
-- TOC entry 6226 (class 0 OID 0)
-- Dependencies: 9
-- Name: acao; Type: ACL; Schema: -; Owner: acao
--

REVOKE ALL ON SCHEMA acao FROM PUBLIC;
REVOKE ALL ON SCHEMA acao FROM acao;
GRANT ALL ON SCHEMA acao TO acao;
GRANT ALL ON SCHEMA acao TO pmf;


--
-- TOC entry 6227 (class 0 OID 0)
-- Dependencies: 171
-- Name: alertas; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON TABLE alertas FROM PUBLIC;
REVOKE ALL ON TABLE alertas FROM acao;
GRANT ALL ON TABLE alertas TO acao;
GRANT ALL ON TABLE alertas TO pmf;


--
-- TOC entry 6229 (class 0 OID 0)
-- Dependencies: 172
-- Name: alertas_id_alerta_seq; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON SEQUENCE alertas_id_alerta_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE alertas_id_alerta_seq FROM acao;
GRANT ALL ON SEQUENCE alertas_id_alerta_seq TO acao;
GRANT ALL ON SEQUENCE alertas_id_alerta_seq TO pmf;


--
-- TOC entry 6231 (class 0 OID 0)
-- Dependencies: 175
-- Name: consolidacao; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON TABLE consolidacao FROM PUBLIC;
REVOKE ALL ON TABLE consolidacao FROM acao;
GRANT ALL ON TABLE consolidacao TO acao;
GRANT ALL ON TABLE consolidacao TO pmf;


--
-- TOC entry 6233 (class 0 OID 0)
-- Dependencies: 176
-- Name: consolidacao_id_consolidacao_seq; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON SEQUENCE consolidacao_id_consolidacao_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE consolidacao_id_consolidacao_seq FROM acao;
GRANT ALL ON SEQUENCE consolidacao_id_consolidacao_seq TO acao;
GRANT ALL ON SEQUENCE consolidacao_id_consolidacao_seq TO pmf;


--
-- TOC entry 6234 (class 0 OID 0)
-- Dependencies: 177
-- Name: consolidador; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON TABLE consolidador FROM PUBLIC;
REVOKE ALL ON TABLE consolidador FROM acao;
GRANT ALL ON TABLE consolidador TO acao;
GRANT ALL ON TABLE consolidador TO pmf;


--
-- TOC entry 6235 (class 0 OID 0)
-- Dependencies: 178
-- Name: definicao_consolidacao; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON TABLE definicao_consolidacao FROM PUBLIC;
REVOKE ALL ON TABLE definicao_consolidacao FROM acao;
GRANT ALL ON TABLE definicao_consolidacao TO acao;
GRANT ALL ON TABLE definicao_consolidacao TO pmf;


--
-- TOC entry 6237 (class 0 OID 0)
-- Dependencies: 179
-- Name: definicao_consolidacao_id_definicao_consolidacao_seq; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON SEQUENCE definicao_consolidacao_id_definicao_consolidacao_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE definicao_consolidacao_id_definicao_consolidacao_seq FROM acao;
GRANT ALL ON SEQUENCE definicao_consolidacao_id_definicao_consolidacao_seq TO acao;
GRANT ALL ON SEQUENCE definicao_consolidacao_id_definicao_consolidacao_seq TO pmf;


--
-- TOC entry 6238 (class 0 OID 0)
-- Dependencies: 180
-- Name: digitador; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON TABLE digitador FROM PUBLIC;
REVOKE ALL ON TABLE digitador FROM acao;
GRANT ALL ON TABLE digitador TO acao;
GRANT ALL ON TABLE digitador TO pmf;


--
-- TOC entry 6239 (class 0 OID 0)
-- Dependencies: 182
-- Name: entrada_consolidacao; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON TABLE entrada_consolidacao FROM PUBLIC;
REVOKE ALL ON TABLE entrada_consolidacao FROM acao;
GRANT ALL ON TABLE entrada_consolidacao TO acao;
GRANT ALL ON TABLE entrada_consolidacao TO pmf;


--
-- TOC entry 6242 (class 0 OID 0)
-- Dependencies: 187
-- Name: etapa_coleta_dados; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON TABLE etapa_coleta_dados FROM PUBLIC;
REVOKE ALL ON TABLE etapa_coleta_dados FROM acao;
GRANT ALL ON TABLE etapa_coleta_dados TO acao;
GRANT ALL ON TABLE etapa_coleta_dados TO pmf;


--
-- TOC entry 6243 (class 0 OID 0)
-- Dependencies: 188
-- Name: etapa_transformacao; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON TABLE etapa_transformacao FROM PUBLIC;
REVOKE ALL ON TABLE etapa_transformacao FROM acao;
GRANT ALL ON TABLE etapa_transformacao TO acao;
GRANT ALL ON TABLE etapa_transformacao TO pmf;


--
-- TOC entry 6244 (class 0 OID 0)
-- Dependencies: 189
-- Name: etapa_validacao; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON TABLE etapa_validacao FROM PUBLIC;
REVOKE ALL ON TABLE etapa_validacao FROM acao;
GRANT ALL ON TABLE etapa_validacao TO acao;
GRANT ALL ON TABLE etapa_validacao TO pmf;


--
-- TOC entry 6247 (class 0 OID 0)
-- Dependencies: 193
-- Name: instrumento; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON TABLE instrumento FROM PUBLIC;
REVOKE ALL ON TABLE instrumento FROM acao;
GRANT ALL ON TABLE instrumento TO acao;
GRANT ALL ON TABLE instrumento TO pmf;


--
-- TOC entry 6248 (class 0 OID 0)
-- Dependencies: 194
-- Name: leitura; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON TABLE leitura FROM PUBLIC;
REVOKE ALL ON TABLE leitura FROM acao;
GRANT ALL ON TABLE leitura TO acao;
GRANT ALL ON TABLE leitura TO pmf;


--
-- TOC entry 6250 (class 0 OID 0)
-- Dependencies: 195
-- Name: leitura_id_leitura_seq; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON SEQUENCE leitura_id_leitura_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE leitura_id_leitura_seq FROM acao;
GRANT ALL ON SEQUENCE leitura_id_leitura_seq TO acao;
GRANT ALL ON SEQUENCE leitura_id_leitura_seq TO pmf;


--
-- TOC entry 6253 (class 0 OID 0)
-- Dependencies: 203
-- Name: projeto; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON TABLE projeto FROM PUBLIC;
REVOKE ALL ON TABLE projeto FROM acao;
GRANT ALL ON TABLE projeto TO acao;
GRANT ALL ON TABLE projeto TO pmf;


--
-- TOC entry 6255 (class 0 OID 0)
-- Dependencies: 204
-- Name: projeto_id_projeto_seq; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON SEQUENCE projeto_id_projeto_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE projeto_id_projeto_seq FROM acao;
GRANT ALL ON SEQUENCE projeto_id_projeto_seq TO acao;
GRANT ALL ON SEQUENCE projeto_id_projeto_seq TO pmf;


--
-- TOC entry 6257 (class 0 OID 0)
-- Dependencies: 207
-- Name: revisor; Type: ACL; Schema: acao; Owner: acao
--

REVOKE ALL ON TABLE revisor FROM PUBLIC;
REVOKE ALL ON TABLE revisor FROM acao;
GRANT ALL ON TABLE revisor TO acao;
GRANT ALL ON TABLE revisor TO pmf;


-- Completed on 2012-07-30 10:54:48 BRT

--
-- PostgreSQL database dump complete
--

